# IO

> IO is a smart plug Hybrid app, has voice command functions and valtage consumption features based on PHP
  and Javascript